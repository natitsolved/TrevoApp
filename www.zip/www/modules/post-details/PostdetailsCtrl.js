app.controller('PostdetailsCtrl', function ($scope) {
    
   
});